from .ener import EnerStdLoss
from .ener import EnerDipoleLoss
from .tensor import TensorLoss

