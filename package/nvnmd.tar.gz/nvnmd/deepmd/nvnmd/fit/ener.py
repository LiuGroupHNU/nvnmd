
from deepmd.env import tf 
from deepmd.env import GLOBAL_TF_FLOAT_PRECISION
from deepmd.nvnmd.utils.config import nvnmd_cfg
from deepmd.nvnmd.utils.network import one_layer as one_layer_nvnmd
from deepmd.utils.network import one_layer as one_layer_deepmd

