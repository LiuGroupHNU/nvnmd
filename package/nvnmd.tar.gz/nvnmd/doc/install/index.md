# Installation

- [Easy install](easy-install.md)
- [Install from source code](install-from-source.md)
- [Install LAMMPS](install-lammps.md)
- [Install i-PI](install-ipi.md)
- [Install GROMACS](install-gromacs.md)
- [Building conda packages](build-conda.md)