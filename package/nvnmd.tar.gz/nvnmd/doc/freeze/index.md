# Freeze and Compress

- [Freeze a model](freeze.md)
- [Compress a model](compress.md)
