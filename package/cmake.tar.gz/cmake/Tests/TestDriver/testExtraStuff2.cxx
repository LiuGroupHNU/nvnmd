int testExtraStuff2()
{
  return 1;
}
