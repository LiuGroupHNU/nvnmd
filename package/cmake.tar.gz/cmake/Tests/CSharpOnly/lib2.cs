namespace CSharpOnly
{
    public class Lib2
    {
        public int myVal = 42;

        public Lib2()
        {}
    }
}
