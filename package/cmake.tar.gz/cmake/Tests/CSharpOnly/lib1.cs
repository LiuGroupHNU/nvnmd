namespace CSharpOnly
{
    public class Lib1
    {
        public static int getResult()
        {
            return 23;
        }
    }
}
