class Foo
{
  public Foo()
  {
  }

  public void printName()
  {
    System.out.println("Foo");
  }
}
