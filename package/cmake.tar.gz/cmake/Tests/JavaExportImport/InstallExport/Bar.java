class Bar
{
  public Bar()
  {
  }

  public void printName()
  {
    System.out.println("Bar");
  }
}
