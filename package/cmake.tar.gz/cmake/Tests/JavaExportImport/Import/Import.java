class Import
{
  public static void main(String args[])
  {
    Foo foo = new Foo();
    Bar bar = new Bar();
    foo.printName();
    bar.printName();
  }
}
