extern int bar1_from_bar3(void);
int bar3(void)
{
  return bar1_from_bar3();
}
