extern int foo2b(void);
int foo1b(void)
{
  return foo2b();
}
