extern int foo2c(void);
int foo1c(void)
{
  return foo2c();
}
