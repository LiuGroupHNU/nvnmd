extern int foo3c(void);
int foo2c(void)
{
  return foo3c();
}
