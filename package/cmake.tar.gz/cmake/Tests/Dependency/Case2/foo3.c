extern int foo1b(void);
int foo3(void)
{
  return foo1b();
}
