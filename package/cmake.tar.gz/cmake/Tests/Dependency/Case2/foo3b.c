extern int foo1c(void);
int foo3b(void)
{
  return foo1c();
}
