int foo3c(void)
{
  return 0;
}
