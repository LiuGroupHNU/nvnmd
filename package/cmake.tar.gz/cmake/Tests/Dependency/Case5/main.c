void bar(void);

int main(int argc, char* argv[])
{
  bar();
  return 0;
}
