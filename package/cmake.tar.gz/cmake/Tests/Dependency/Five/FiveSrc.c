void TwoFunction();

void FiveFunction()
{
  TwoFunction();
}
