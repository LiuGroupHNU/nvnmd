extern int a();

int b()
{
  return a() + 17;
}
