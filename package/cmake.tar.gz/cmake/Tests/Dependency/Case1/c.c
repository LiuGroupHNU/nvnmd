extern int b();

int c()
{
  return b() + 42;
}
