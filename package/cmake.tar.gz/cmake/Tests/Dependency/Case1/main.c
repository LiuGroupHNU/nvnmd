extern int b();
extern int c();
extern int d();

int main()
{
  c();
  b();
  d();
}
