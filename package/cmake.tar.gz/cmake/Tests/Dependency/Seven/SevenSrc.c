void TwoFunction();

void SevenFunction()
{
  TwoFunction();
}
