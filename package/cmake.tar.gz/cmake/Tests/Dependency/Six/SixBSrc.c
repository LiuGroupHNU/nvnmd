void TwoFunction();
void FiveFunction();
void FourFunction();

void SixBFunction()
{
  TwoFunction();
  FiveFunction();
  FourFunction();
}
