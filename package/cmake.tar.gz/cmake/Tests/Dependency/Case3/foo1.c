extern int foo2(void);
int foo1(void)
{
  return foo2();
}
