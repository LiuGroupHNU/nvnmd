void OneFunction()
{
}
