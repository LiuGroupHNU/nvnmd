void NoDepAFunction()
{
}
