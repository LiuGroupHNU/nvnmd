#include "b.h"
EXPORT_B int b2(void)
{
  return 0;
}
