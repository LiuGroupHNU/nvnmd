extern "C" int acxx(void)
{
  return 0;
}
