
#ifdef NEEDED_TO_WORK
int icasetest()
{
  return 0;
}
#endif
