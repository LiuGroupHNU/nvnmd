
#include "framework.h"

int main(int, char**)
{
  framework();
  return 0;
}
