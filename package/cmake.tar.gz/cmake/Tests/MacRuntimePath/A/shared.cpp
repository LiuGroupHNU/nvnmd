
#include "shared.h"
#include "stdio.h"

void shared()
{
  printf("shared\n");
}
