
#include "framework2.h"
#include "stdio.h"

void framework2()
{
  printf("framework 2\n");
}
