
#include "shared.h"

int main(int, char**)
{
  shared();
  return 0;
}
