
#include "framework.h"
#include "stdio.h"

void framework()
{
  printf("framework\n");
}
