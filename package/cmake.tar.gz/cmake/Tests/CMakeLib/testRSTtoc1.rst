.. |not replaced| replace:: not replaced across toctree
First TOC entry.
