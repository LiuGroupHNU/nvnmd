|substitution|

.. |cross-include substitution| replace:: Cross-include substitution text
   with :command:`some_cmd` reference.

End of first include.
