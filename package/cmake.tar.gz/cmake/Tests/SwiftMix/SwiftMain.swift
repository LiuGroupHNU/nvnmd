import Foundation

@objc class SwiftMainClass : NSObject {
  class func SwiftMain() -> Int32 {
    dump("Hello World!");
    return 0;
  }
}
