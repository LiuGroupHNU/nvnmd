extern int ObjCMain(int argc, char const* const argv[]);
int main(int argc, char* argv[])
{
  return ObjCMain(argc, argv);
}
