#import "SwiftMix-Swift.h"
int ObjCMain(int argc, char const* const argv[]) {
  return [SwiftMainClass SwiftMain];
}
