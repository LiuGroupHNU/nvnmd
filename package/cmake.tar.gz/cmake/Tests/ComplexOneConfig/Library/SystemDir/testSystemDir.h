// Purposely leave off the return type to create a warning.
foo()
{
  return 0;
}
