#include <string.h>

#ifdef CMAKE_IS_REALLY_FUN
This is a problem. Looks like REMOVE_DEFINITION does not work
#endif

int file2()
{
  return 1;
}
