// This header should not be compiled directly but through inclusion in A.cxx
#include "A.h"
