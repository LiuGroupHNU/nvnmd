int NameConflictTest2()
{
  return 0;
}
