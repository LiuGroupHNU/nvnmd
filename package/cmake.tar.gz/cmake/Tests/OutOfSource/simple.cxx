int simple()
{
  return 123;
}
