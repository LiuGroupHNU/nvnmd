int subdir(void)
{
  return 0;
}
