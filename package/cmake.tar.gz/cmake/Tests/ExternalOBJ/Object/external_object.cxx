int external_object_function()
{
  return 0;
}
