#include <iostream>

void print_message(const char* const Message)
{
  std::cout << Message;
}
