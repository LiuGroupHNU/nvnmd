
void foo(void)
{
}
