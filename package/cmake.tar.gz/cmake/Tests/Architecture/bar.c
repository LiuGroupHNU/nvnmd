extern int foo(void);
int main()
{
  return foo();
}
