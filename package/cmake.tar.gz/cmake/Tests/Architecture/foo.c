int foo(void)
{
  return 0;
}
