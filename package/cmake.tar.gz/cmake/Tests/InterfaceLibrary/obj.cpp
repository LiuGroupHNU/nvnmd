int obj()
{
  return 0;
}
