
#include "shareddependlib.h"

int SharedDependLibObject::foo() const
{
  return 0;
}
