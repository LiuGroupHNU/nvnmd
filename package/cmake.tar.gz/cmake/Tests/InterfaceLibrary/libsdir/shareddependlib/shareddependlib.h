
#ifndef SHAREDDEPENDLIB_H
#define SHAREDDEPENDLIB_H

#include "shareddependlib_export.h"

struct SHAREDDEPENDLIB_EXPORT SharedDependLibObject
{
  int foo() const;
};

#endif
