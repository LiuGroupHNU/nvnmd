extern int item_undefined();
int item()
{
  return item_undefined();
}
