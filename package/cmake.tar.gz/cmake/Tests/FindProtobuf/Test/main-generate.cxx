#include <example.pb.h>

int main()
{
  example::msgs::Example msg;

  return 0;
}
