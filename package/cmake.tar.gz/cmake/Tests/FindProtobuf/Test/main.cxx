#include <google/protobuf/stubs/common.h>

int main()
{
  GOOGLE_PROTOBUF_VERIFY_VERSION;

  return 0;
}
