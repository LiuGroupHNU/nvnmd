#include <google/protobuf/compiler/command_line_interface.h>

int main()
{
  google::protobuf::compiler::CommandLineInterface();

  return 0;
}
