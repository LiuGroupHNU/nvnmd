
int object(void)
{
  return 0;
}
