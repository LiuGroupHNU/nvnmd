
#include <QObject>

class Foo : QObject
{
  Q_OBJECT
public:
  Foo();
};
