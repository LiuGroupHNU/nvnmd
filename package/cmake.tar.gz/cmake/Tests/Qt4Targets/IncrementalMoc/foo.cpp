
#include "foo.h"

Foo::Foo()
  : QObject(0)
{
}
