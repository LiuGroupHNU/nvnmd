
#ifndef MYINTERFACE_H
#define MYINTERFACE_H

class MyInterface
{
};

Q_DECLARE_INTERFACE(MyInterface, "org.cmake.example.MyInterface")

#endif
