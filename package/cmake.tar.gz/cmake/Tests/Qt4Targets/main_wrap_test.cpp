
#include <QObject>

#include "mywrapobject.h"

int main(int argc, char** argv)
{
  MyWrapObject mwo;
  mwo.objectName();
  return 0;
}
