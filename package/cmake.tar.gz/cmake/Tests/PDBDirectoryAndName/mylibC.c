__declspec(dllexport) int mylibC()
{
  return 1;
}
