extern void simpleLib();
int main()
{
  simpleLib();
  return 0;
}
