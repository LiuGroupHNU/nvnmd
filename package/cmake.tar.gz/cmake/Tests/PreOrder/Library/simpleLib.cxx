void simpleLib()
{
}
