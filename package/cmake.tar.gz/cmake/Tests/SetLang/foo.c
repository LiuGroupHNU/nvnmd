int foo()
{
  int r = 10;
  r++;
  int ret = r + 10;
  return ret;
}
