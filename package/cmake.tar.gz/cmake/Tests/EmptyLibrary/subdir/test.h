extern int dummy;
