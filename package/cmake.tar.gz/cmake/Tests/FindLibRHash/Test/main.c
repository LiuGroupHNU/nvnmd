#include <rhash.h>

int main()
{
  rhash_library_init();
  return 0;
}
