
int main(int argc, char**)
{
  typeof(argc) ret = 0;
  return ret;
}
