
constexpr int foo()
{
  return 0;
}

int main(int argc, char**)
{
  return foo();
}
