#include "mylib.h"
#include "stdio.h"

void mylib_function()
{
  printf("This is mylib");
}
