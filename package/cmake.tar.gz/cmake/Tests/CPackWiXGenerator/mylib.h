void mylib_function();
