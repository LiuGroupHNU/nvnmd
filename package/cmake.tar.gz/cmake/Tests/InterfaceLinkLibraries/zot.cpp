#include "zot.h"

int zot()
{
  return 0;
}
