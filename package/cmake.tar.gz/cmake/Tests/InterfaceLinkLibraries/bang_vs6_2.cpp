#include "bang.cpp"
